%% parameter %%
N = 500;
Well_width = 5e-9; % unit = m
Mass = 0.19*9.11e-31; % unit = kg
h = 6.63e-34/(2*pi); 
A = zeros(N-2);


%% define matrix %%
for i = 1 : N-2
    for j = 1 : N-2
        
        if i == j
            A(i, j) = -2;
            
        elseif abs(i - j) == 1 
            A(i, j) = 1;
            
        else 
            A(i, j) = 0;
        end
    end
end

%% solution %%

[eigenvector, eigenvalue] = eig(A);

eigenvector_minimum = eigenvector(:,find(-1*diag(eigenvalue) == min(-1*diag(eigenvalue))));
k_square_minmum = min(-1*diag(eigenvalue))/(Well_width/(N-1))^2;
Energy_minimum = h^2/(2*Mass)*k_square_minmum;
Wavefunction_minimum = [0; eigenvector_minimum; 0]/norm(eigenvector_minimum);