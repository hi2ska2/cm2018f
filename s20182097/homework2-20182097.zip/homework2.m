%% parameter %%
N = 5000;
Layer_1 = [20e-9 15];  %[length (m) relative permittivity]
Layer_2 = [100e-9 12.11];
Width = Layer_1(1, 1) + Layer_2(1, 1);
A = zeros(N);
b = zeros(N,1);
b(N,1) = 1;
eps_0 = 8.8541878176e-12;

%% define matrix %%
for i = 1 : N
    for j = 1 : N
        Position_before = Width/(N-1)*((i - 1) - 0.5);
        Position_after = Width/(N-1)*((i - 1) + 0.5);
        
        if (i == 1) || (i == N)
            A(i, j) = 0;
            
        elseif i == j
            A(i, j) = -(r_permitivity(Position_before, Layer_1, Layer_2 ) + r_permitivity(Position_after, Layer_1, Layer_2 ));
            
        elseif i == j + 1 
            A(i, j) = r_permitivity(Position_before, Layer_1, Layer_2 );
            
        elseif i == j - 1  
            A(i, j) = r_permitivity(Position_after, Layer_1, Layer_2 );
            
        end
       
    end
end

A(1,1) = 1;
A(N, N) = 1;

%% solution %%
Position = Width/(N-1)*transpose([0:N-1]);
Sample_potential = [Position A\b];

E_1 = interp1(Sample_potential(:, 1), Sample_potential(:, 2), Layer_1(1, 1))/Layer_1(1, 1);     %E_1 = V_1/length_first_layer
E_2 = (1-interp1(Sample_potential(:, 1), Sample_potential(:, 2), Layer_1(1, 1)))/Layer_2(1, 1);     %E_2 = V_2/length_second_layer =  (1 - V_1)/length_second_layer
Charge_density = E_1 * Layer_1(1, 2) * eps_0;       %Q(C/m^2) = E_1 * V_1 = E_2 * V_2 = E_tot * V_tot

%C_1, C_2 and C_tot ==> F/m^2 
C_1 = Charge_density/(E_1*Layer_1(1, 1));   
C_2 = Charge_density/(E_2*Layer_2(1, 1));                                                           
C_tol = C_1 * C_2 / (C_1 + C_2);    

C_tol_solution = eps_0 * (Layer_1(1, 2)/Layer_1(1, 1)) * (Layer_2(1, 2)/Layer_2(1, 1)) / (Layer_1(1, 2)/Layer_1(1, 1) + Layer_2(1, 2)/Layer_2(1, 1));   %C/A = eps/d in case of pararell plate



